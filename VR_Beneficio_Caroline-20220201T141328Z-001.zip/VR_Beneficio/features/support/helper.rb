#require 'tiny_tds'

#Dir[File.join(File.dirname(__FILE__), '../pages/*_page.rb')].each { |file| require file }

#module PageObjects
 # def operation_crud
 #   @Oper_CRUD ||= CRUD.new
#  end
#end

