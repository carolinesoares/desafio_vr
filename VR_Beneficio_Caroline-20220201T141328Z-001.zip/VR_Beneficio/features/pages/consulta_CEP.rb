require 'HTTParty'
require 'httparty/request'
require 'httparty/response/headers'
#require_relative '../hooks/hook'

class API
include HTTParty
base_url 'https://viacep.com.br/ws/01001000/json/'

def retrieve(cep)
  self.class.get("/employee/#{ cep }")
end

class API_invalido

  include HTTParty
  base_url 'https://viacep.com.br/ws/01001007/json/'
  
  def retrieve(cep)
    self.class.get("/employee/#{ cep }")
  end
  
