Dado("a API Consulta Endereço por CEP no IBGE") do
  @buscar_cep = API.new
  @buscar_cep_erro = API_invalido.new
end

#consulta
Quando("enviar a requisição") do
  puts $response.body
  @buscar_cep = JSON.parse($response)['cep']
end    
                                                            
Então("visualizo o status 200 e response") do
  puts @buscar_cep.retrieve(@buscar_cep)
  expect(@buscar_cep.retrieve(@buscar_cep).code).to eq (200)
end  

#consultainvalida
Quando("enviar a requisição") do
  puts $response.body
  @buscar_cep_erro = JSON.parse($response)['cep']
end    
                                                            
Então("Então visualizo o status 400 de erro") do
  puts @buscar_cep_erro.retrieve(@buscar_cep_erro)
  expect(@buscar_cep_erro.retrieve(@buscar_cep_erro).code).to eq (200)
end  